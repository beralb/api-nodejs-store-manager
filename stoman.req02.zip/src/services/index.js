const productService = require('./product.service');

module.exports = {
  productService,
};
