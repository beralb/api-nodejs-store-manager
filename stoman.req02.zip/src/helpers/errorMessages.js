module.exports = {
  // notFoundData: 'Não foram localizados dados!',
  notFoundData: 'Product not found',
};
