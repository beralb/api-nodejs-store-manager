module.exports = {
  OK: 200,
  badRequest: 404,
};