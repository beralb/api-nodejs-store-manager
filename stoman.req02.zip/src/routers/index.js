const productRouter = require('./product.router');

module.exports = {
  productRouter,
};