const productController = require('./product.controller');

module.exports = {
  productController,
};
