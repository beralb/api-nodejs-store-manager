const productModel = require('./product.model');

module.exports = {
  productModel,
};
